/* Global Variables */

// Personal API key for OpenWeatherMap API
const baseURL = 'https://api.openweathermap.org/data/2.5/weather?zip=';
const apiKey = '&appid=aae8a908ce5f949d0c9f120c00d5a20c&units=metric';

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.toLocaleString({ month: 'long', day: 'numeric', year: 'numeric' });

document.getElementById('generate').addEventListener('click', performAction);

function performAction(e) {
    const postCode = document.getElementById('zip').value;
    const feelings = document.getElementById('feelings').value;
    console.log(newDate);
    getTemperature(baseURL, postCode, apiKey)
        .then(function (data) {
            // Add data to POST request
            postData('http://localhost:3000/addWeatherData', {
                temperature: data.main.temp,
                date: newDate,
                user_response: feelings
            })
                // Function updates UI
                .then(function () {
                    updateUI()
                })
        })
}

// Async GET
const getTemperature = async (baseURL, code, apiKey) => {
    // const getTemperature = async (url)=>{
    const response = await fetch(baseURL + code + apiKey)
    console.log(response);
    try {
        const data = await response.json();
        console.log(data);
        console.log('First');
        return data;
    }
    catch (error) {
        console.log('error', error);
    }
}

// Async POST
const postData = async (url = '', data = {}) => {
    const postRequest = await fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    });
    try {
        const newData = await postRequest.json();
        return newData;
    } catch (error) {
        console.log('Error', error);
    }
}

// Update user interface
const updateUI = async () => {
    const request = await fetch('http://localhost:3000/all');
    try {
        const allData = await request.json();
        document.getElementById('date').innerHTML = allData.date;
        document.getElementById('temp').innerHTML = allData.temperature;
        document.getElementById('content').innerHTML = allData.user_response;
    }
    catch (error) {
        console.log('error', error);
    }
}