# Weather-Journal App 
eather-journa-app for Udacity Web Development Professional Nanodegree Program

## Overview
This project requires you to create an asynchronous web app that uses Web API and user data to dynamically update the UI with weather data and response in text field , providing current date.


### Node and Express 
In this project  been using Node and 'Express.Node' and 'Express' should be installed on the local machine. The project file 'server.js' should require 'express()', and should create an instance of their app using express,The Express app instance should be pointed to the project folder with '.HTML, .CSS, .JS' files.

### Project 
The 'cors' package should be installed in the project from the command line, required in the project file 'server.js', and the instance of the app should be setup to use 'cors()'.
The 'body-parser' package should be installed and included in the project.

### Local Server
Local server should be running and producing feedback to the Command Line through working callback function.

### API Credentials
Create API credentials on OpenWeatherMap.com 

## How To Use
using node server.js in code editor for active server.js file and typing in Browser   http://localhost:3000 , and used app.